
#ifndef NTL_vec_vec_zz_pE__H
#define NTL_vec_vec_zz_pE__H

#include <NTL/vec_lzz_pE.h>

NTL_OPEN_NNS

NTL_vector_decl(vec_zz_pE,vec_vec_zz_pE)

NTL_eq_vector_decl(vec_zz_pE,vec_vec_zz_pE)

NTL_io_vector_decl(vec_zz_pE,vec_vec_zz_pE)

NTL_CLOSE_NNS

#endif
