
#include <NTL/vec_vec_GF2.h>

#include <NTL/new.h>

NTL_START_IMPL


NTL_vector_impl(vec_GF2,vec_vec_GF2)

NTL_eq_vector_impl(vec_GF2,vec_vec_GF2)

NTL_io_vector_impl(vec_GF2,vec_vec_GF2)

NTL_END_IMPL

