
#include <NTL/vec_vec_RR.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(vec_RR,vec_vec_RR)

NTL_eq_vector_impl(vec_RR,vec_vec_RR)

NTL_io_vector_impl(vec_RR,vec_vec_RR)

NTL_END_IMPL

