
#include <NTL/vec_vec_ZZ.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(vec_ZZ,vec_vec_ZZ)

NTL_eq_vector_impl(vec_ZZ,vec_vec_ZZ)

NTL_io_vector_impl(vec_ZZ,vec_vec_ZZ)

NTL_END_IMPL

