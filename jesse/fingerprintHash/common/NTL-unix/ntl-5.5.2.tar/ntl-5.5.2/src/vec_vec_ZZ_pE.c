
#include <NTL/vec_vec_ZZ_pE.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(vec_ZZ_pE,vec_vec_ZZ_pE)

NTL_eq_vector_impl(vec_ZZ_pE,vec_vec_ZZ_pE)

NTL_io_vector_impl(vec_ZZ_pE,vec_vec_ZZ_pE)

NTL_END_IMPL
